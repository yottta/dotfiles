#!/bin/bash

su -c '/bin/bash install_packages.sh'
/bin/bash make_symlinks.sh

